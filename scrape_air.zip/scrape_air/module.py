# Contents of module.py
def my_function():
    print("Hello from the imported module!")

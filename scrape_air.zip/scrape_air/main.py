# Import the entire module
import module

# Now you can use the module's functions
module.my_function()  # This will print: "Hello from the imported module!"
